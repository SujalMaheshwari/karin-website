import { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Shared
import Cursor        from "./components/Cursor.jsx";
import LoadingScreen from "./components/LoadingScreen.jsx";
import { ToastContainer, useToast } from "./components/Toast.jsx";

// Home sections
import Navbar        from "./components/Navbar.jsx";
import Hero          from "./components/Hero.jsx";
import Stats         from "./components/Stats.jsx";
import Services      from "./components/Services.jsx";
import Work          from "./components/Work.jsx";
import HowWeWork     from "./components/HowWeWork.jsx";
import Team          from "./components/Team.jsx";
import Testimonials  from "./components/Testimonials.jsx";
import FAQ           from "./components/FAQ.jsx";
import Contact       from "./components/Contact.jsx";
import Footer        from "./components/Footer.jsx";

// Pages
import AdminLogin     from "./pages/AdminLogin.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";
import NotFound       from "./components/NotFound.jsx";

/* ── Home page ── */
function HomePage({ dark, setDark, toast }) {
  const scrollTo = (id) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <>
      <Navbar dark={dark} setDark={setDark} scrollTo={scrollTo} />
      <main>
        <Hero         scrollTo={scrollTo} />
        <Stats        />
        <Services     />
        <Work         />
        <HowWeWork    />
        <Team         />
        <Testimonials />
        <FAQ          />
        <Contact      toast={toast} />
      </main>
      <Footer />
    </>
  );
}

/* ── Root App ── */
export default function App() {
  // Theme — persisted to localStorage
  const [dark, setDark] = useState(() => {
    try {
      const saved = localStorage.getItem("karin_theme");
      return saved ? saved === "dark" : true;
    } catch { return true; }
  });

  // Loading screen
  const [loaded, setLoaded] = useState(false);

  // Toast system
  const { toasts, toast } = useToast();

  // Apply theme to body + persist
  useEffect(() => {
    document.body.className = dark ? "dark" : "light";
    try { localStorage.setItem("karin_theme", dark ? "dark" : "light"); } catch {}
  }, [dark]);

  // SEO meta tags
  useEffect(() => {
    document.title = "KARIN Pvt. Ltd. | Software Development Studio";

    const upsertMeta = (attr, attrVal, content) => {
      let el = document.querySelector(`meta[${attr}="${attrVal}"]`);
      if (!el) { el = document.createElement("meta"); el.setAttribute(attr, attrVal); document.head.appendChild(el); }
      el.setAttribute("content", content);
    };

    upsertMeta("name",     "description",       "KARIN Pvt. Ltd. builds scalable web apps, AI integrations, and modern digital products for startups and businesses.");
    upsertMeta("name",     "keywords",          "software development, full-stack, React, Node.js, AI, LLM, mobile app, Bhopal, India, KARIN");
    upsertMeta("name",     "author",            "KARIN Pvt. Ltd.");
    upsertMeta("name",     "robots",            "index, follow");
    upsertMeta("property", "og:title",          "KARIN Pvt. Ltd. | Software Development Studio");
    upsertMeta("property", "og:description",    "Focused engineering studio in Bhopal, India. Full-stack · Mobile · AI.");
    upsertMeta("property", "og:type",           "website");
    upsertMeta("property", "og:url",            "https://karinpvt.in");
    upsertMeta("name",     "twitter:card",      "summary_large_image");
    upsertMeta("name",     "twitter:title",     "KARIN Pvt. Ltd.");
    upsertMeta("name",     "twitter:description","Full-stack software studio — Bhopal, India.");
  }, []);

  return (
    <BrowserRouter>
      <Cursor />

      {/* Loading screen — plays once */}
      {!loaded && <LoadingScreen onDone={() => setLoaded(true)} />}

      {/* Global toast notifications */}
      <ToastContainer
        toasts={toasts}
        onRemove={(id) => {}}
      />

      <Routes>
        <Route path="/"                element={<HomePage dark={dark} setDark={setDark} toast={toast} />} />
        <Route path="/admin"           element={<AdminLogin toast={toast} />} />
        <Route path="/admin/dashboard" element={<AdminDashboard toast={toast} />} />
        <Route path="*"                element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}
