import "./Hero.css";

export default function Hero({ scrollTo }) {
  return (
    <div className="hero-wrap" id="hero">
      <div className="hero-grid" />
      <div className="hero-glow" />
      <div className="hero-glow2" />

      <div className="hero-inner">
        <p className="hero-eyebrow">Software Development Studio · Bhopal, India</p>

        <h1 className="hero-h1">
          Turning<br />
          <em>Ideas</em> Into<br />
          <span className="hilight">Products.</span>
        </h1>

        <p className="hero-sub">
          KARIN Pvt. Ltd. is a focused software development studio building
          full-stack web apps, mobile experiences, and AI-powered products —
          from concept to launch.
        </p>

        <div className="hero-btns">
          <a
            href="#"
            className="btn-primary"
            onClick={(e) => { e.preventDefault(); scrollTo("contact"); }}
          >
            Let's Build Together →
          </a>
          <a
            href="#"
            className="btn-ghost"
            onClick={(e) => { e.preventDefault(); scrollTo("work"); }}
          >
            See Our Work
          </a>
        </div>

        <div className="hero-loc">Bhopal, Madhya Pradesh, India</div>
      </div>
    </div>
  );
}
