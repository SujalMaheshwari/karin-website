import { HOW_WE_WORK } from "../data/index.js";
import Reveal from "./Reveal.jsx";
import "./HowWeWork.css";

export default function HowWeWork() {
  return (
    <div className="hww-bg">
      <section id="process" className="hww-section">
        <Reveal>
          <div className="sec-head">
            <div>
              <div className="sec-label">Our Process</div>
              <h2 className="sec-title">How We <em>Work</em></h2>
            </div>
            <p className="hww-sub">
              A clear, structured process that keeps you informed<br />
              and in control at every stage.
            </p>
          </div>
        </Reveal>

        <div className="hww-grid">
          {HOW_WE_WORK.map((item, i) => (
            <Reveal key={item.step} delay={i * 0.1}>
              <div className="hww-card">
                <div className="hww-top">
                  <span className="hww-step">{item.step}</span>
                  <span className="hww-icon">{item.icon}</span>
                </div>
                <h3 className="hww-title">{item.title}</h3>
                <p className="hww-desc">{item.desc}</p>
                {/* Connector line — hidden on last card */}
                {i < HOW_WE_WORK.length - 1 && (
                  <div className="hww-connector" />
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </div>
  );
}
