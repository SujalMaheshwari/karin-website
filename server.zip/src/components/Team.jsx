import { TEAM } from "../data/index.js";
import Reveal from "./Reveal.jsx";
import "./Team.css";

export default function Team() {
  return (
    <section id="team">
      <Reveal>
        <div className="sec-head">
          <div>
            <div className="sec-label">The People</div>
            <h2 className="sec-title">Our <em>Team</em></h2>
          </div>
        </div>
      </Reveal>

      <div className="team-grid">
        {TEAM.map((m, i) => (
          <Reveal key={m.name} delay={i * 0.1}>
            <div className="team-card">
              <div className="team-avatar">{m.initial}</div>
              <div className="team-name">{m.name}</div>
              <div className="team-role">{m.role}</div>
              <p className="team-bio">{m.bio}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
