import "./Footer.css";

export default function Footer() {
  return (
    <footer>
      <div className="footer-inner">
        <div>
          <div className="footer-logo">
            <span className="logo-k">K</span>
            <span className="logo-rest">ARIN</span>
            <span className="logo-pvt">Pvt. Ltd.</span>
          </div>
          <div className="footer-copy">
            © 2025 KARIN Pvt. Ltd. · Bhopal, India · All rights reserved.
          </div>
        </div>

        <div className="footer-links">
          <a href="#" target="_blank" rel="noreferrer">LinkedIn</a>
          <a href="#" target="_blank" rel="noreferrer">GitHub</a>
          <a href="#" target="_blank" rel="noreferrer">Twitter</a>
        </div>
      </div>
    </footer>
  );
}
