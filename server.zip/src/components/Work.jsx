import { PROJECTS } from "../data/index.js";
import Reveal from "./Reveal.jsx";
import "./Work.css";

export default function Work() {
  return (
    <div className="work-bg">
      <div className="work-inner" id="work">
        <Reveal>
          <div className="sec-head">
            <div>
              <div className="sec-label">Case Studies</div>
              <h2 className="sec-title">Selected <em>Work</em></h2>
            </div>
          </div>
          {/* Realistic subtitle */}
          <p className="work-subtitle">
            Selected Internal Builds & Product Concepts
          </p>
        </Reveal>

        <div className="projects-list">
          {PROJECTS.map((p, i) => (
            <Reveal key={p.title} delay={i * 0.08}>
              <div
                className="proj-row"
                style={{ "--proj-color": p.color }}
              >
                <div className="proj-info">
                  <div className="proj-type">{p.type}</div>
                  <div className="proj-name">{p.title}</div>
                  <div className="proj-desc">{p.desc}</div>
                  <div className="proj-tags">
                    {p.tags.map((t) => (
                      <span className="proj-tag" key={t}>{t}</span>
                    ))}
                  </div>
                </div>
                <div className="proj-right">
                  <div className="proj-cat">{p.category}</div>
                  <div className="proj-year">{p.year}</div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}
