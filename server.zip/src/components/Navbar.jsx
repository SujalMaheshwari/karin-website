import { useState, useEffect, useRef } from "react";
import "./Navbar.css";

const NAV_LINKS = ["Services", "Work", "Process", "Team", "FAQ", "Contact"];

const SECTION_MAP = {
  Services: "services",
  Work:     "work",
  Process:  "process",
  Team:     "team",
  FAQ:      "faq",
  Contact:  "contact",
};

export default function Navbar({ dark, setDark, scrollTo }) {
  const [scrolled,  setScrolled]  = useState(false);
  const [menuOpen,  setMenuOpen]  = useState(false);
  const [hidden,    setHidden]    = useState(false);
  const [active,    setActive]    = useState("");
  const [hovered,   setHovered]   = useState("");
  const lastScrollY = useRef(0);

  /* ── Hide on scroll down, reveal on scroll up ── */
  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      if (y > 120) setHidden(y > lastScrollY.current);
      else setHidden(false);
      lastScrollY.current = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  /* ── Active section tracker ── */
  useEffect(() => {
    const ids = Object.values(SECTION_MAP);
    const observers = [];
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (!el) return;
      const obs = new IntersectionObserver(
        ([entry]) => { if (entry.isIntersecting) setActive(id); },
        { threshold: 0.25 }
      );
      obs.observe(el);
      observers.push(obs);
    });
    return () => observers.forEach((o) => o.disconnect());
  }, []);

  const handleNav = (id) => { scrollTo(id); setMenuOpen(false); };

  return (
    <>
      <nav className={[
        scrolled ? "scrolled" : "",
        hidden   ? "nav-hidden" : "",
      ].join(" ").trim()}>

        {/* ── LOGO ── */}
        <div className="logo" onClick={() => scrollTo("hero")}>
          <div className="logo-mark">K</div>
          <div className="logo-text">
            <span className="logo-name">ARIN</span>
            <span className="logo-tag">Pvt. Ltd.</span>
          </div>
        </div>

        {/* ── NAV LINKS ── */}
        <ul className="nav-links">
          {NAV_LINKS.map((l) => {
            const id       = SECTION_MAP[l];
            const isActive = active === id;
            const isHover  = hovered === id;
            return (
              <li key={l}>
                <a
                  href="#"
                  className={isActive ? "nav-active" : ""}
                  onMouseEnter={() => setHovered(id)}
                  onMouseLeave={() => setHovered("")}
                  onClick={(e) => { e.preventDefault(); handleNav(id); }}
                >
                  <span className="nav-label">{l}</span>
                  <span
                    className={`nav-line ${isActive || isHover ? "nav-line-show" : ""} ${isActive ? "nav-line-active" : ""}`}
                  />
                </a>
              </li>
            );
          })}
        </ul>

        {/* ── RIGHT ── */}
        <div className="nav-right">
          {/* Theme toggle */}
          <button
            className="theme-toggle"
            onClick={() => setDark((d) => !d)}
            aria-label="Toggle theme"
          >
            <span className="ti sun">☀</span>
            <span className="ti moon">◑</span>
            <span className="knob" style={{ left: dark ? "28px" : "4px" }} />
          </button>

          {/* CTA */}
          <button className="nav-cta" onClick={() => handleNav("contact")}>
            Start a Project →
          </button>
        </div>

        {/* Hamburger */}
        <button
          className={`hamburger${menuOpen ? " open" : ""}`}
          onClick={() => setMenuOpen((m) => !m)}
          aria-label="Toggle menu"
        >
          <span /><span /><span />
        </button>
      </nav>

      {/* ── MOBILE MENU ── */}
      <div className={`mobile-menu${menuOpen ? " open" : ""}`}>
        <div className="mob-logo">
          <span className="mob-logo-k">K</span>ARIN
        </div>
        <div className="mob-links">
          {NAV_LINKS.map((l, i) => (
            <a
              key={l}
              href="#"
              className={active === SECTION_MAP[l] ? "mob-active" : ""}
              onClick={(e) => { e.preventDefault(); handleNav(SECTION_MAP[l]); }}
            >
              <span className="mob-num">0{i + 1}</span>
              {l}
            </a>
          ))}
        </div>
        <div className="mob-bottom">
          <div className="mob-theme">
            <span>Switch theme</span>
            <button
              className="theme-toggle"
              onClick={() => setDark((d) => !d)}
              style={{ cursor: "pointer" }}
            >
              <span className="ti sun">☀</span>
              <span className="ti moon">◑</span>
              <span className="knob" style={{ left: dark ? "28px" : "4px" }} />
            </button>
          </div>
          <button
            className="btn-primary mob-cta"
            onClick={() => handleNav("contact")}
            style={{ cursor: "pointer" }}
          >
            Start a Project →
          </button>
        </div>
      </div>
    </>
  );
}
