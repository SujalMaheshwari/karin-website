import { useEffect, useState } from "react";
import "./LoadingScreen.css";

export default function LoadingScreen({ onDone }) {
  const [phase, setPhase]       = useState("enter");   // enter → hold → exit
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Animate progress bar 0 → 100 over ~1.6s
    let val = 0;
    const step = () => {
      val += Math.random() * 14 + 4;
      if (val >= 100) {
        setProgress(100);
        setTimeout(() => setPhase("exit"), 300);
        return;
      }
      setProgress(Math.min(val, 100));
      setTimeout(step, 80);
    };
    const t = setTimeout(step, 200);

    return () => clearTimeout(t);
  }, []);

  // When exit animation ends, tell App we're done
  const handleAnimEnd = (e) => {
    if (phase === "exit" && e.animationName === "ls-fade-out") {
      onDone();
    }
  };

  return (
    <div
      className={`ls-wrap ${phase === "exit" ? "ls-exit" : ""}`}
      onAnimationEnd={handleAnimEnd}
    >
      {/* Background grid */}
      <div className="ls-grid" />

      {/* Center content */}
      <div className="ls-center">
        <div className="ls-logo-wrap">
          <div className="ls-logo">
            <span className="ls-k">K</span>
            <span className="ls-arin">ARIN</span>
          </div>
          <div className="ls-pvt">Pvt. Ltd.</div>
        </div>

        <div className="ls-tagline">Turning Ideas Into Products</div>

        {/* Progress bar */}
        <div className="ls-bar-track">
          <div
            className="ls-bar-fill"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="ls-percent">
          {Math.round(progress)}<span>%</span>
        </div>
      </div>

      {/* Corner label */}
      <div className="ls-corner">Bhopal · India · 2025</div>
    </div>
  );
}
