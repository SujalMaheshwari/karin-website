import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./AdminDashboard.css";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

export default function AdminDashboard() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [selected, setSelected] = useState(null);
  const [admin, setAdmin]       = useState(null);
  const navigate                = useNavigate();

  const token = localStorage.getItem("karin_admin_token");

  const authHeaders = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };

  /* Verify token on mount */
  useEffect(() => {
    if (!token) { navigate("/admin"); return; }
    fetch(`${API_URL}/api/auth/me`, { headers: authHeaders })
      .then((r) => r.json())
      .then((d) => { if (!d.success) navigate("/admin"); else setAdmin(d.admin); })
      .catch(() => navigate("/admin"));
  }, []);

  /* Fetch messages */
  useEffect(() => {
    if (!token) return;
    setLoading(true);
    fetch(`${API_URL}/api/contact`, { headers: authHeaders })
      .then((r) => r.json())
      .then((d) => { if (d.success) setMessages(d.data); })
      .finally(() => setLoading(false));
  }, []);

  const markRead = async (id) => {
    await fetch(`${API_URL}/api/contact/${id}/read`, {
      method: "PATCH", headers: authHeaders,
    });
    setMessages((prev) =>
      prev.map((m) => (m._id === id ? { ...m, isRead: true } : m))
    );
  };

  const deleteMsg = async (id) => {
    if (!confirm("Delete this message?")) return;
    await fetch(`${API_URL}/api/contact/${id}`, {
      method: "DELETE", headers: authHeaders,
    });
    setMessages((prev) => prev.filter((m) => m._id !== id));
    if (selected?._id === id) setSelected(null);
  };

  const logout = () => {
    localStorage.removeItem("karin_admin_token");
    navigate("/admin");
  };

  const openMessage = (msg) => {
    setSelected(msg);
    if (!msg.isRead) markRead(msg._id);
  };

  const unread = messages.filter((m) => !m.isRead).length;

  const fmt = (iso) =>
    new Date(iso).toLocaleDateString("en-IN", {
      day: "numeric", month: "short", year: "numeric",
    });

  return (
    <div className="ad-wrap">
      {/* TOP BAR */}
      <header className="ad-header">
        <div className="ad-header-logo">
          <span className="ad-k">K</span>ARIN
          <span className="ad-badge">Admin</span>
        </div>
        <div className="ad-header-right">
          {admin && (
            <span className="ad-username">👤 {admin.username}</span>
          )}
          <a href="/" className="ad-site-link">← View Site</a>
          <button className="ad-logout" onClick={logout}>Log Out</button>
        </div>
      </header>

      <div className="ad-body">
        {/* SIDEBAR — message list */}
        <aside className="ad-sidebar">
          <div className="ad-sidebar-head">
            <span>Inbox</span>
            {unread > 0 && (
              <span className="ad-unread-badge">{unread} new</span>
            )}
          </div>

          {loading && (
            <div className="ad-loading">Loading messages…</div>
          )}

          {!loading && messages.length === 0 && (
            <div className="ad-empty">No messages yet.</div>
          )}

          {messages.map((msg) => (
            <div
              key={msg._id}
              className={`ad-msg-row ${!msg.isRead ? "unread" : ""} ${selected?._id === msg._id ? "active" : ""}`}
              onClick={() => openMessage(msg)}
            >
              <div className="ad-msg-name">{msg.name}</div>
              <div className="ad-msg-preview">
                {msg.message.slice(0, 60)}{msg.message.length > 60 ? "…" : ""}
              </div>
              <div className="ad-msg-date">{fmt(msg.createdAt)}</div>
            </div>
          ))}
        </aside>

        {/* MAIN — message detail */}
        <main className="ad-main">
          {!selected ? (
            <div className="ad-placeholder">
              <div className="ad-placeholder-icon">◈</div>
              <p>Select a message to read it</p>
            </div>
          ) : (
            <div className="ad-detail">
              <div className="ad-detail-header">
                <div>
                  <h2 className="ad-detail-name">{selected.name}</h2>
                  <a
                    className="ad-detail-email"
                    href={`mailto:${selected.email}`}
                  >
                    {selected.email}
                  </a>
                </div>
                <div className="ad-detail-actions">
                  <a
                    className="ad-reply-btn"
                    href={`mailto:${selected.email}?subject=Re: Your enquiry — KARIN Pvt. Ltd.`}
                  >
                    Reply via Email →
                  </a>
                  <button
                    className="ad-delete-btn"
                    onClick={() => deleteMsg(selected._id)}
                  >
                    Delete
                  </button>
                </div>
              </div>

              <div className="ad-detail-meta">
                <span>Received: {fmt(selected.createdAt)}</span>
                <span className={`ad-status ${selected.isRead ? "read" : "unread"}`}>
                  {selected.isRead ? "✓ Read" : "● Unread"}
                </span>
              </div>

              <div className="ad-detail-body">
                {selected.message}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
