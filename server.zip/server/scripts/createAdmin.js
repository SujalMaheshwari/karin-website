/**
 * Run this ONCE to create the admin account in MongoDB:
 *   node server/scripts/createAdmin.js
 *
 * It reads ADMIN_USERNAME and ADMIN_PASSWORD from your .env file.
 */

import "dotenv/config";
import mongoose from "mongoose";
import Admin from "../models/Admin.js";

const run = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✓ Connected to MongoDB");

    const existing = await Admin.findOne({ username: process.env.ADMIN_USERNAME });
    if (existing) {
      console.log("⚠ Admin already exists. Delete it in MongoDB first if you want to recreate.");
      process.exit(0);
    }

    await Admin.create({
      username: process.env.ADMIN_USERNAME,
      password: process.env.ADMIN_PASSWORD,
    });

    console.log(`✓ Admin created: username = "${process.env.ADMIN_USERNAME}"`);
    console.log("  You can now log in at /admin on your frontend.");
  } catch (err) {
    console.error("✗ Error:", err.message);
  } finally {
    await mongoose.disconnect();
    process.exit(0);
  }
};

run();
