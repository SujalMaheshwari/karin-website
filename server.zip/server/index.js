import "dotenv/config";
import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import rateLimit from "express-rate-limit";

import contactRoutes from "./routes/contact.js";
import authRoutes    from "./routes/auth.js";

const app  = express();
const PORT = process.env.PORT || 5000;

/* ── CORS ── */
app.use(cors({
  origin: process.env.CLIENT_URL || "http://localhost:5173",
  credentials: true,
}));

/* ── Body parsers ── */
app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({ extended: true }));

/* ── Global rate limit ── */
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
}));

/* ── Routes ── */
app.use("/api/contact", contactRoutes);
app.use("/api/auth",    authRoutes);

/* ── Health check ── */
app.get("/api/health", (_, res) => {
  res.json({
    success: true,
    service: "KARIN Backend",
    status:  "running",
    time:    new Date().toISOString(),
  });
});

/* ── 404 handler ── */
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.method} ${req.path} not found.` });
});

/* ── Global error handler ── */
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({ success: false, message: "Internal server error." });
});

/* ── Connect DB then start server ── */
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✓ MongoDB connected");
    app.listen(PORT, () => {
      console.log(`✓ KARIN backend running → http://localhost:${PORT}`);
      console.log(`  Health check → http://localhost:${PORT}/api/health`);
    });
  })
  .catch((err) => {
    console.error("✗ MongoDB connection failed:", err.message);
    process.exit(1);
  });
