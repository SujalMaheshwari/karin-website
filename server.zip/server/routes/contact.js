import express from "express";
import nodemailer from "nodemailer";
import rateLimit from "express-rate-limit";
import Message from "../models/Message.js";
import { protect } from "../middleware/auth.js";

const router = express.Router();

/* ── Rate limit: max 5 submissions per IP per 15 minutes ── */
const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { success: false, message: "Too many requests. Please try again in 15 minutes." },
});

/* ── Nodemailer transporter ── */
const createTransporter = () =>
  nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

/* ════════════════════════════════════
   POST /api/contact
   Public — submit the contact form
════════════════════════════════════ */
router.post("/", contactLimiter, async (req, res) => {
  try {
    const { name, email, message } = req.body;

    // Basic validation
    if (!name?.trim() || !email?.trim() || !message?.trim()) {
      return res.status(400).json({ success: false, message: "All fields are required." });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ success: false, message: "Invalid email address." });
    }
    if (message.trim().length < 10) {
      return res.status(400).json({ success: false, message: "Message is too short." });
    }

    // Save to MongoDB
    const saved = await Message.create({
      name:      name.trim(),
      email:     email.trim().toLowerCase(),
      message:   message.trim(),
      ipAddress: req.ip,
    });

    // Send notification email to KARIN team
    const transporter = createTransporter();
    await transporter.sendMail({
      from:    `"KARIN Website" <${process.env.SMTP_USER}>`,
      to:      process.env.CONTACT_RECEIVER,
      subject: `New enquiry from ${name}`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:auto;padding:32px;border:1px solid #eee;border-radius:8px;">
          <h2 style="color:#0b0c0e;margin-bottom:4px;">New Project Enquiry</h2>
          <p style="color:#888;font-size:13px;margin-top:0;">KARIN Pvt. Ltd. — Contact Form</p>
          <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> <a href="mailto:${email}">${email}</a></p>
          <p><strong>Message:</strong></p>
          <div style="background:#f9f9f9;padding:16px;border-radius:6px;color:#333;line-height:1.7;">
            ${message.replace(/\n/g, "<br>")}
          </div>
          <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
          <p style="color:#aaa;font-size:12px;">Sent: ${new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })} IST</p>
        </div>
      `,
    });

    // Send auto-reply to sender
    await transporter.sendMail({
      from:    `"KARIN Pvt. Ltd." <${process.env.SMTP_USER}>`,
      to:      email,
      subject: "We received your message — KARIN Pvt. Ltd.",
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:auto;padding:32px;border:1px solid #eee;border-radius:8px;">
          <h2 style="color:#0b0c0e;">Thanks, ${name}!</h2>
          <p style="color:#444;line-height:1.7;">
            We've received your message and will get back to you within <strong>24 hours</strong>.
          </p>
          <p style="color:#444;line-height:1.7;">
            In the meantime, feel free to reply to this email with any additional details.
          </p>
          <hr style="border:none;border-top:1px solid #eee;margin:24px 0;">
          <p style="color:#888;font-size:13px;">KARIN Pvt. Ltd. · Bhopal, India · hello@karinpvt.in</p>
        </div>
      `,
    });

    res.status(201).json({
      success: true,
      message: "Message received. We'll be in touch within 24 hours.",
      id: saved._id,
    });
  } catch (err) {
    console.error("Contact route error:", err);
    res.status(500).json({ success: false, message: "Server error. Please email us directly." });
  }
});

/* ════════════════════════════════════
   GET /api/contact
   Protected — admin: list all messages
════════════════════════════════════ */
router.get("/", protect, async (req, res) => {
  try {
    const page  = Math.max(1, parseInt(req.query.page)  || 1);
    const limit = Math.min(50, parseInt(req.query.limit) || 20);
    const skip  = (page - 1) * limit;

    const [messages, total] = await Promise.all([
      Message.find().sort({ createdAt: -1 }).skip(skip).limit(limit),
      Message.countDocuments(),
    ]);

    res.json({
      success: true,
      data: messages,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch messages." });
  }
});

/* ════════════════════════════════════
   PATCH /api/contact/:id/read
   Protected — mark message as read
════════════════════════════════════ */
router.patch("/:id/read", protect, async (req, res) => {
  try {
    const msg = await Message.findByIdAndUpdate(
      req.params.id,
      { isRead: true },
      { new: true }
    );
    if (!msg) return res.status(404).json({ success: false, message: "Message not found." });
    res.json({ success: true, data: msg });
  } catch {
    res.status(500).json({ success: false, message: "Failed to update message." });
  }
});

/* ════════════════════════════════════
   DELETE /api/contact/:id
   Protected — delete a message
════════════════════════════════════ */
router.delete("/:id", protect, async (req, res) => {
  try {
    const msg = await Message.findByIdAndDelete(req.params.id);
    if (!msg) return res.status(404).json({ success: false, message: "Message not found." });
    res.json({ success: true, message: "Message deleted." });
  } catch {
    res.status(500).json({ success: false, message: "Failed to delete message." });
  }
});

export default router;
